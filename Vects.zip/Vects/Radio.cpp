//
// Created by jlpereira on 11/16/18.
//

#include "Radio.h"

Radio::Radio() {}

Radio::Radio(const string &nombre, const string &genero) : nombre(nombre), genero(genero) {}

Radio::~Radio() {

}

const string &Radio::getNombre() const {
    return nombre;
}

void Radio::setNombre(const string &nombre) {
    Radio::nombre = nombre;
}

const string &Radio::getGenero() const {
    return genero;
}

void Radio::setGenero(const string &genero) {
    Radio::genero = genero;
}

const vector<Canciones> &Radio::getSongs() const {
    return songs;
}

void Radio::setSongs(const vector<Canciones> &songs) {
    Radio::songs = songs;
}

void Radio::addCancion(const Canciones &ca) {
    songs.push_back(ca);
}
