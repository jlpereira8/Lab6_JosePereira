//
// Created by jlpereira on 11/16/18.
//

#include "Playlists.h"

Playlists::Playlists() {}

Playlists::Playlists(const string &nombre_pl, const string &descripcion) : nombre_pl(nombre_pl),
                                                                           descripcion(descripcion) {}

const string &Playlists::getNombre_pl() const {
    return nombre_pl;
}

void Playlists::setNombre_pl(const string &nombre_pl) {
    Playlists::nombre_pl = nombre_pl;
}

const string &Playlists::getDescripcion() const {
    return descripcion;
}

void Playlists::setDescripcion(const string &descripcion) {
    Playlists::descripcion = descripcion;
}

const vector<Canciones> &Playlists::getCanciones_playlist() const {
    return canciones_playlist;
}

void Playlists::setCanciones_playlist(const vector<Canciones> &canciones_playlist) {
    Playlists::canciones_playlist = canciones_playlist;
}

Playlists::~Playlists() {

}

void Playlists::addCancion(const Canciones &ca) {
    canciones_playlist.push_back(ca);
}
