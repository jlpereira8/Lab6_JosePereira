//
// Created by jlpereira on 11/16/18.
//

#ifndef VECTS_CANCIONES_H
#define VECTS_CANCIONES_H

#include <string>
using std::string;

class Canciones {
private:
    string titulo;
    string genero;
    int duracion_sec;
    int veces_reproducida;
    string artista;
public:
    Canciones();

    Canciones(const string &titulo, const string &genero, int duracion_sec, int veces_reproducida);

    virtual ~Canciones();

    const string &getTitulo() const;

    void setTitulo(const string &titulo);

    const string &getGenero() const;

    void setGenero(const string &genero);

    int getDuracion_sec() const;

    void setDuracion_sec(int duracion_sec);

    int getVeces_reproducida() const;

    void setVeces_reproducida(int veces_reproducida);

    const string &getArtista() const;

    void setArtista(const string &artista);

};


#endif //VECTS_CANCIONES_H
