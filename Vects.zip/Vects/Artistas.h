//
// Created by jlpereira on 11/16/18.
//

#ifndef VECTS_ARTISTAS_H
#define VECTS_ARTISTAS_H

#include "Canciones.h"
#include <string>
using std::string;

#include <vector>
using std::vector;

class Artistas {
private:
    string nombre;
    int rep_totales;
    vector<Canciones> lista_canciones;
public:
    Artistas();
    Artistas(const string &nombre, int rep_totales);
    virtual ~Artistas();

    const string &getNombre() const;

    void setNombre(const string &nombre);

    int getRep_totales() const;

    void setRep_totales(int rep_totales);

    const vector<Canciones> &getLista_canciones() const;

    void setLista_canciones(const vector<Canciones> &lista_canciones);

    //Metodo secsual
    void addCancion(const Canciones &ca);

};


#endif //VECTS_ARTISTAS_H
