//
// Created by jlpereira on 11/16/18.
//

#include "Artistas.h"

Artistas::Artistas() {}

Artistas::Artistas(const string &nombre, int rep_totales) : nombre(nombre), rep_totales(rep_totales) {}

Artistas::~Artistas() {

}

const string &Artistas::getNombre() const {
    return nombre;
}

void Artistas::setNombre(const string &nombre) {
    Artistas::nombre = nombre;
}

int Artistas::getRep_totales() const {
    return rep_totales;
}

void Artistas::setRep_totales(int rep_totales) {
    Artistas::rep_totales = rep_totales;
}

const vector<Canciones> &Artistas::getLista_canciones() const {
    return lista_canciones;
}

void Artistas::setLista_canciones(const vector<Canciones> &lista_canciones) {
    Artistas::lista_canciones = lista_canciones;
}

void Artistas::addCancion(const Canciones &ca) {
    lista_canciones.push_back(ca);
}
