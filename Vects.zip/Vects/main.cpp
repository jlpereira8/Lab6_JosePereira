#include <iostream>
#include "Artistas.h"
#include "Playlists.h"
#include "Radio.h"
#include "Canciones.h"

using std::cout;
using std::cin;
using std::endl;

#include <string>
using std::string;

#include <vector>
using std::vector;



int main() {
    int cen=1;
    vector<Artistas> artistas;
    vector<Playlists> playlists;
    vector<Radio> radio;
    vector<Canciones> canciones;
    string titulo_c="",cancion_c="";
    while(cen==1){
        cout<<"*************Spotify****************"<<endl;
        cout<<endl;
        cout<<"Ahora suena: "<<titulo_c<<" de: "<<cancion_c<<endl;
        cout<<endl;
        cout<<"1) Crear Artistas"<<endl;
        cout<<"2) Crear Playlists"<<endl;
        cout<<"3) Crear Canciones"<<endl;
        cout<<"4) Crear Estaciones de Radio"<<endl;
        cout<<"5) Agregar canciones a playlists"<<endl;
        cout<<"6) Mostrar playlists con toda su info"<<endl;
        cout<<"7) Mostrar estacion de radio con toda su info"<<endl;
        cout<<"8) Mostrar la cancion y Artista mas Popular"<<endl;
        cout<<"9) Reproducir Musica"<<endl;
        cout<<"10) Salir"<<endl;
        int des;
        cin>>des;
        if(des==1){
            cout<<"*************Crear Artista***************"<<endl;
            string nombre;
            cout<<"Ingrese el nombre del Artista"<<endl;
            cin>>nombre;
            Artistas a(nombre,0);
            artistas.push_back(a);

            cout<<"Artista creado correctamente"<<endl;
        }else if(des==2){
            cout<<"*************Crear Playlist***************"<<endl;
            string nombre,desc;
            cout<<"Ingrese el nombre de la playlist"<<endl;
            cin>>nombre;
            cout<<"Ingrese la descripcion de: "<<nombre<<endl;
            cin>>desc;
            Playlists p(nombre,desc);
            playlists.push_back(p);
            cout<<"Playlist creada correctamente"<<endl;
        }else if(des==3){
            cout<<"*************Crear Cancion***************"<<endl;
            string titulo,genero;
            int duracion;
            if(artistas.size()>0){
                cout<<"Estos son los artistas disponibles:"<<endl;
                for (int i = 0; i < artistas.size(); ++i) {
                    cout<<i<<") "<<artistas[i].getNombre()<<endl;
                }
                cout<<"Ingrese la posicion del artista "<<endl;
                int pos;
                cin>>pos;
                cout<<"Ingrese el titulo de la cancion:"<<endl;
                cin>>titulo;
                cout<<"Ingrese el genero de la cancion:"<<endl;
                cin>>genero;
                cout<<"Ingrese la duracion (en segundos):"<<endl;
                cin>>duracion;
                Canciones can(titulo,genero,duracion,0);
                can.setArtista(artistas[pos].getNombre());
                artistas[pos].addCancion(can);
                canciones.push_back(can);
                for (int j = 0; j <radio.size() ; ++j) {
                    if(radio[j].getGenero()==genero){
                        radio[j].addCancion(can);
                        cout<<"Se agrego: "<<can.getTitulo()<<" a la radio: "<<radio[j].getNombre()<<endl;
                    }
                }
                cout<<"Cancion creada y agregada al artista correctamente"<<endl;
            }else{
                cout<<"NO hay artistas"<<endl;
            }
        }else if(des==4){
            cout<<"*************Crear Radio***************"<<endl;
            string nombre,genero;
            cout<<"Ingrese el nombre de la Radio"<<endl;
            cin>>nombre;
            cout<<"Ingrese el genero de la Radio"<<endl;
            cin>>genero;
            Radio r(nombre,genero);
            int max=radio.size();
            for (int i = 0; i < canciones.size() ; ++i) {
                if(genero==canciones[i].getGenero()){
                    cout<<"Se agrego: "<<canciones[i].getTitulo()<<" a la playlist"<<endl;
                    r.addCancion(canciones[i]);
                }
            }
            radio.push_back(r);
            cout<<"Radio creada Correctamente"<<endl;
        }else if(des==5){
            if(playlists.size()>0){
                cout<<"*************Playlists*************"<<endl;
                for (int i = 0; i <playlists.size() ; ++i) {
                    cout<<i<<") "<<playlists[i].getNombre_pl()<<endl;
                    cout<<"Descripcion: "<<playlists[i].getDescripcion()<<endl;
                }
                int pos;
                cout<<"Ingrese la posicion de la Playlist "<<endl;
                cin>>pos;
                cout<<"*************Canciones***************"<<endl;
                for (int i = 0; i <canciones.size() ; ++i) {
                    cout<<i<<") "<<canciones[i].getTitulo()<<endl;
                }
                int can;
                cout<<"Ingrese la posicion de la Cancion"<<endl;
                cin>>can;

                playlists[pos].addCancion(canciones[can]);
                cout<<"La cancion: "<<canciones[can].getTitulo()<<" se agrego correctamente a la playlist: "<<playlists[pos].getNombre_pl()<<endl;

            }else{
                cout<<"No hay playlists"<<endl;
            }
        }else if(des==6){
            cout<<"*************Mostrar Playlists*************"<<endl;
            int max=0;
            for (int i = 0; i <playlists.size() ; ++i) {
                cout<<i+1<<") "<<playlists[i].getNombre_pl()<<endl;
                cout<<"Canciones: "<<endl;
                for (int j = 0; j < playlists[i].getCanciones_playlist().size(); ++j) {
                    cout<<"  *"<<playlists[i].getCanciones_playlist().at(j).getTitulo()<<endl;
                    max+=playlists[i].getCanciones_playlist().at(j).getDuracion_sec();
                }
                int min=max/60;
                int secs=(max-(min*60));
                cout<<"Minutos totales en la playlist: "<<max/60<<" Segundos:"<<secs<<endl;
            }
        }else if(des==7){
            cout<<"*************Mostrar Radios*************"<<endl;
            int max=0;
            for (int i = 0; i <radio.size() ; ++i) {
                cout<<i+1<<") "<<radio[i].getNombre()<<endl;
                cout<<"Canciones: "<<endl;
                for (int j = 0; j < radio[i].getSongs().size(); ++j) {
                    cout<<"  *"<<radio[i].getSongs().at(j).getTitulo()<<endl;
                    max+=radio[i].getSongs().at(j).getDuracion_sec();
                }
                int min=max/60;
                int secs=(max-(min*60));
                cout<<"Minutos totales en la playlist: "<<max/60<<" Segundos:"<<secs<<endl;
            }
        }else if(des==8){

            cout<<"La cancion mas reproducida es: "<<titulo_c<<" y su artista es: "<<cancion_c<<endl;

        }else if(des==9){
            cout<<"*************Mostrar Playlists*************"<<endl;
            int max=0;
            for (int i = 0; i <playlists.size() ; ++i) {
                cout<<i+1<<") "<<playlists[i].getNombre_pl()<<endl;
                cout<<"Canciones: "<<endl;
                for (int j = 0; j < playlists[i].getCanciones_playlist().size(); ++j) {
                    cout<<j<<") "<<playlists[i].getCanciones_playlist().at(j).getTitulo()<<endl;
                    max+=playlists[i].getCanciones_playlist().at(j).getDuracion_sec();
                }
                int min=max/60;
                int secs=(max-(min*60));
                cout<<"Minutos totales en la playlist: "<<max/60<<" Segundos:"<<secs<<endl;
            }
            int p1,p2;
            cout<<"Ingrese la posicion de la playlist"<<endl;
            cin>>p1;
            cout<<"Ingrese la posicion de la cancion"<<endl;
            cin>>p2;
            titulo_c=playlists[p1].getCanciones_playlist().at(p2).getTitulo();
            cancion_c=playlists[p1].getCanciones_playlist().at(p2).getArtista();

            ((Canciones&)playlists[p1].getCanciones_playlist().at(p2)).setVeces_reproducida(playlists[p1].getCanciones_playlist().at(p2).getVeces_reproducida()+1);

        }else if (des==10){
            cen=69;

        }else{
            cout<<"Opcion no valida"<<endl;
        }
   }

    return 0;
}