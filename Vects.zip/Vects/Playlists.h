//
// Created by jlpereira on 11/16/18.
//

#ifndef VECTS_PLAYLISTS_H
#define VECTS_PLAYLISTS_H

#include "Canciones.h"
#include <string>
using std::string;

#include <vector>
using std::vector;

class Playlists {
private:
    string nombre_pl;
    string descripcion;
    vector<Canciones> canciones_playlist;
public:
    Playlists();

    Playlists(const string &nombre_pl, const string &descripcion);

    virtual ~Playlists();

    //
    void addCancion(const Canciones &ca);
    //

    const string &getNombre_pl() const;

    void setNombre_pl(const string &nombre_pl);

    const string &getDescripcion() const;

    void setDescripcion(const string &descripcion);

    const vector<Canciones> &getCanciones_playlist() const;

    void setCanciones_playlist(const vector<Canciones> &canciones_playlist);
};


#endif //VECTS_PLAYLISTS_H
