//
// Created by jlpereira on 11/16/18.
//

#include "Canciones.h"

Canciones::Canciones() {}

Canciones::Canciones(const string &titulo, const string &genero, int duracion_sec, int veces_reproducida) : titulo(
        titulo), genero(genero), duracion_sec(duracion_sec), veces_reproducida(veces_reproducida) {}

Canciones::~Canciones() {

}

const string &Canciones::getTitulo() const {
    return titulo;
}

void Canciones::setTitulo(const string &titulo) {
    Canciones::titulo = titulo;
}

const string &Canciones::getGenero() const {
    return genero;
}

void Canciones::setGenero(const string &genero) {
    Canciones::genero = genero;
}

int Canciones::getDuracion_sec() const {
    return duracion_sec;
}

void Canciones::setDuracion_sec(int duracion_sec) {
    Canciones::duracion_sec = duracion_sec;
}

int Canciones::getVeces_reproducida() const {
    return veces_reproducida;
}

void Canciones::setVeces_reproducida(int veces_reproducida) {
    Canciones::veces_reproducida = veces_reproducida;
}

const string &Canciones::getArtista() const {
    return artista;
}

void Canciones::setArtista(const string &artista) {
    Canciones::artista = artista;
}
