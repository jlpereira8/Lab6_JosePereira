//
// Created by jlpereira on 11/16/18.
//

#ifndef VECTS_RADIO_H
#define VECTS_RADIO_H

#include "Canciones.h"
#include <string>
using std::string;

#include <vector>
using std::vector;

class Radio {
private:
    string nombre;
    string genero;
    vector<Canciones> songs;
public:
    Radio();

    Radio(const string &nombre, const string &genero);

    virtual ~Radio();

    const string &getNombre() const;

    void setNombre(const string &nombre);

    const string &getGenero() const;

    void setGenero(const string &genero);

    const vector<Canciones> &getSongs() const;

    void setSongs(const vector<Canciones> &songs);

    //Sexo

    void addCancion(const Canciones &ca);


};


#endif //VECTS_RADIO_H
